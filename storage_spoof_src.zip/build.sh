#!/bin/sh
set -e
cd "$(dirname "$0")"
(cd module && ndk-build)
rm -rf out storage_spoof.zip
cp -r template out
mkdir out/zygisk
for a in arm64-v8a armeabi-v7a; do cp module/libs/$a/libstorage_spoof.so out/zygisk/$a.so; done
(cd out && zip -r ../storage_spoof.zip .)
