#include "zygisk.hpp"
#include <dlfcn.h>
#include <elf.h>
#include <fcntl.h>
#include <link.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/statvfs.h>
#include <sys/vfs.h>
#include <unistd.h>

static uint64_t g_cap;
static bool g_on;

template <class S> static void clampfs(S *s, uint64_t bs) {
    if (!bs) return;
    uint64_t cap = g_cap / bs;
    if (s->f_bavail > cap) s->f_bavail = cap;
    if (s->f_bfree > cap) s->f_bfree = cap;
}

#ifdef __LP64__
typedef struct statfs sfs64_t;
typedef struct statvfs svfs64_t;
typedef ElfW(Rela) Rel_t;
#define R_SYM(i) ELF64_R_SYM(i)
#define R_TYP(i) ELF64_R_TYPE(i)
#define JSLOT 1026
#define GDAT 1025
#define REL_TAG DT_RELA
#define RELSZ_TAG DT_RELASZ
#else
struct sfs64_t { uint32_t f_type, f_bsize; uint64_t f_blocks, f_bfree, f_bavail; };
struct svfs64_t { uint32_t f_bsize, f_frsize; uint64_t f_blocks, f_bfree, f_bavail; };
typedef ElfW(Rel) Rel_t;
#define R_SYM(i) ELF32_R_SYM(i)
#define R_TYP(i) ELF32_R_TYPE(i)
#define JSLOT 22
#define GDAT 21
#define REL_TAG DT_REL
#define RELSZ_TAG DT_RELSZ
#endif

#define PATH_HOOK(N, T, BS) \
    static int (*o_##N)(const char *, T *); \
    static int h_##N(const char *p, T *s) { int r = o_##N(p, s); if (!r) clampfs(s, BS); return r; }
#define FD_HOOK(N, T, BS) \
    static int (*o_##N)(int, T *); \
    static int h_##N(int fd, T *s) { int r = o_##N(fd, s); if (!r) clampfs(s, BS); return r; }
#define VBS (s->f_frsize ? s->f_frsize : s->f_bsize)

PATH_HOOK(statfs, struct statfs, s->f_bsize)
PATH_HOOK(statfs64, sfs64_t, s->f_bsize)
FD_HOOK(fstatfs, struct statfs, s->f_bsize)
FD_HOOK(fstatfs64, sfs64_t, s->f_bsize)
PATH_HOOK(statvfs, struct statvfs, VBS)
PATH_HOOK(statvfs64, svfs64_t, VBS)
FD_HOOK(fstatvfs, struct statvfs, VBS)
FD_HOOK(fstatvfs64, svfs64_t, VBS)

struct Hook { const char *name; void *fn; void **orig; };
static Hook H[] = {
    {"statfs", (void *)h_statfs, (void **)&o_statfs},
    {"statfs64", (void *)h_statfs64, (void **)&o_statfs64},
    {"fstatfs", (void *)h_fstatfs, (void **)&o_fstatfs},
    {"fstatfs64", (void *)h_fstatfs64, (void **)&o_fstatfs64},
    {"statvfs", (void *)h_statvfs, (void **)&o_statvfs},
    {"statvfs64", (void *)h_statvfs64, (void **)&o_statvfs64},
    {"fstatvfs", (void *)h_fstatvfs, (void **)&o_fstatvfs},
    {"fstatvfs64", (void *)h_fstatvfs64, (void **)&o_fstatvfs64},
};

static void put(void **slot, void *fn) {
    if (*slot == fn) return;
    uintptr_t ps = (uintptr_t)sysconf(_SC_PAGESIZE);
    if (mprotect((void *)((uintptr_t)slot & ~(ps - 1)), ps, PROT_READ | PROT_WRITE)) return;
    *slot = fn;
}

static uintptr_t g_seen[2048];
static int g_nseen;

static int scan_cb(struct dl_phdr_info *i, size_t, void *) {
    const char *n = i->dlpi_name;
    if (!n || !*n || strstr(n, "/libc.so") || strstr(n, "/libdl.so") || strstr(n, "/linker")) return 0;
    uintptr_t b = i->dlpi_addr;
    for (int k = 0; k < g_nseen; k++) if (g_seen[k] == b) return 0;
    ElfW(Dyn) *dyn = nullptr;
    for (int k = 0; k < i->dlpi_phnum; k++)
        if (i->dlpi_phdr[k].p_type == PT_DYNAMIC) dyn = (ElfW(Dyn) *)(b + i->dlpi_phdr[k].p_vaddr);
    if (!dyn) return 0;
    auto fix = [&](uintptr_t p) { return p >= b ? p : b + p; };
    ElfW(Sym) *sym = nullptr;
    const char *str = nullptr;
    uintptr_t jr = 0, rr = 0;
    size_t jsz = 0, rsz = 0;
    for (ElfW(Dyn) *d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_SYMTAB: sym = (ElfW(Sym) *)fix(d->d_un.d_ptr); break;
            case DT_STRTAB: str = (const char *)fix(d->d_un.d_ptr); break;
            case DT_JMPREL: jr = fix(d->d_un.d_ptr); break;
            case DT_PLTRELSZ: jsz = d->d_un.d_val; break;
            case REL_TAG: rr = fix(d->d_un.d_ptr); break;
            case RELSZ_TAG: rsz = d->d_un.d_val; break;
        }
    }
    if (!sym || !str) return 0;
    auto run = [&](uintptr_t t, size_t sz) {
        for (Rel_t *r = (Rel_t *)t; (uintptr_t)r < t + sz; r++) {
            unsigned ty = R_TYP(r->r_info);
            if (ty != JSLOT && ty != GDAT) continue;
            const char *nm = str + sym[R_SYM(r->r_info)].st_name;
            for (auto &h : H)
                if (h.fn && !strcmp(nm, h.name)) put((void **)(b + r->r_offset), h.fn);
        }
    };
    run(jr, jsz);
    run(rr, rsz);
    // shortcut: packed relocs (DT_ANDROID_RELA) are not scanned, add if a lib slips through
    if (g_nseen < 2048) g_seen[g_nseen++] = b;
    return 0;
}

// shortcut: libs loaded more than ~1 min after start are not patched, hook dlopen if that matters
static void *rescan(void *) {
    static const int ms[] = {500, 1000, 2000, 4000, 8000, 16000, 30000};
    for (int m : ms) {
        usleep(m * 1000);
        dl_iterate_phdr(scan_cb, nullptr, nullptr);
    }
    return nullptr;
}

class StorageSpoof : public zygisk::ModuleBase {
    zygisk::Api *api;
    JNIEnv *env;

    void onLoad(zygisk::Api *a, JNIEnv *e) override { api = a; env = e; }

    void preAppSpecialize(zygisk::AppSpecializeArgs *a) override {
        int appid = a->uid % 100000;
        if (appid < 10000 || appid >= 90000 || (a->is_child_zygote && *a->is_child_zygote)) return;
        char name[256] = {0};
        const char *nn = env->GetStringUTFChars(a->nice_name, nullptr);
        if (!nn) return;
        strncpy(name, nn, sizeof(name) - 1);
        env->ReleaseStringUTFChars(a->nice_name, nn);
        char *c = strchr(name, ':');
        if (c) *c = 0;

        g_cap = 2048ull << 20;
        bool listed = false, hit = false;
        int d = api->getModuleDir();
        int f = d >= 0 ? openat(d, "config.txt", O_RDONLY) : -1;
        if (f >= 0) {
            char buf[4096];
            ssize_t n = read(f, buf, sizeof(buf) - 1);
            close(f);
            if (n > 0) {
                buf[n] = 0;
                for (char *l = strtok(buf, "\n"); l; l = strtok(nullptr, "\n")) {
                    while (*l == ' ' || *l == '\t') l++;
                    size_t len = strlen(l);
                    while (len && (l[len - 1] == '\r' || l[len - 1] == ' ' || l[len - 1] == '\t')) l[--len] = 0;
                    if (!*l || *l == '#') continue;
                    if (!strncmp(l, "free_mb=", 8)) g_cap = strtoull(l + 8, nullptr, 10) << 20;
                    else { listed = true; if (!strcmp(l, name)) hit = true; }
                }
            }
        }
        g_on = !listed || hit;
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!g_on) { api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY); return; }
        for (auto &h : H) {
            *h.orig = dlsym(RTLD_DEFAULT, h.name);
            if (!*h.orig) h.fn = nullptr;
        }
        dl_iterate_phdr(scan_cb, nullptr, nullptr);
        pthread_t t;
        if (!pthread_create(&t, nullptr, rescan, nullptr)) pthread_detach(t);
    }
};

REGISTER_ZYGISK_MODULE(StorageSpoof)
