APP_ABI := arm64-v8a armeabi-v7a
APP_STL := none
APP_PLATFORM := android-26
APP_CPPFLAGS := -std=c++17 -fno-exceptions -fno-rtti
