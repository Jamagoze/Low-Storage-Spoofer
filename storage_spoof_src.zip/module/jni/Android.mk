LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := storage_spoof
LOCAL_SRC_FILES := storage_spoof.cpp
LOCAL_LDLIBS := -ldl -lstdc++
include $(BUILD_SHARED_LIBRARY)
